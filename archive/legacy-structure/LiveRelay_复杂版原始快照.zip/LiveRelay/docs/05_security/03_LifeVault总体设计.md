# 03_LifeVault总体设计

> 状态：讨论中  
> 版本：0.1  
> 最后更新：2026-09-05  
> 依赖文档：无

LifeVault = 加密 SQLite（结构化数据与 Blob 索引） + 加密 Blob（照片/PDF/音视频） + 版本/密码元数据 + 单体导出封装。Vault Core 不理解业务语义。
