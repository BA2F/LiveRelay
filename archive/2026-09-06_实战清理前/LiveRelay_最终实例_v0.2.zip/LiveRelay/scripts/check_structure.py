from pathlib import Path

root = Path(__file__).resolve().parents[1]
required = [
    "README.md", "AGENTS.md",
    "docs/00_governance", "docs/10_overview", "docs/20_product",
    "docs/30_design", "docs/40_modules", "docs/50_interfaces",
    "records/adr", "memory/当前项目上下文.md",
    "tasks", "handoffs", "work"
]
missing = [x for x in required if not (root / x).exists()]
if missing:
    print("缺少必要路径：")
    for x in missing:
        print("-", x)
    raise SystemExit(1)

print("核心项目结构检查通过。")
