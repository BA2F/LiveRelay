# LifeVault 总体设计

> 状态：草案
> 版本：0.2  
> 最后更新：2026-09-06  
> 依赖文档：无

## 迁移来源：03_LifeVault总体设计

> 原路径：`docs/05_security/03_LifeVault总体设计.md`  
> 原状态：讨论中

LifeVault = 加密 SQLite（结构化数据与 Blob 索引） + 加密 Blob（照片/PDF/音视频） + 版本/密码元数据 + 单体导出封装。Vault Core 不理解业务语义。

---

## 迁移来源：04_LifeVault运行时结构

> 原路径：`docs/05_security/04_LifeVault运行时结构.md`  
> 原状态：讨论中

运行时倾向目录式：加密 DB + 加密 Blob 目录 + 必要非敏感格式头。支持大文件、流式处理和增量操作。

---

## 迁移来源：05_LifeVault导出格式

> 原路径：`docs/05_security/05_LifeVault导出格式.md`  
> 原状态：待详细设计

用户导出单个 `.lvault`。内部数据库和 Blob 已加密，外层可进一步封装/整体认证以降低元数据泄露。格式应开放、可迁移、可脱离原 App 恢复。
